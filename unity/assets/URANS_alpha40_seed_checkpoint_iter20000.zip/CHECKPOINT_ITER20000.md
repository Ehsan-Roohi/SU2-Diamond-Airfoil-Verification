# Alpha-40 medium seed checkpoint near global iteration 20,000

- Status: CHECKPOINTED, suitable only as a bounded URANS initialization state.
- Solver exit: natural `Exit Success (SU2_CFD)` after local iteration 6,999 of
  the final 7,000-iteration continuation segment.
- Physics: SU2 8.5.0, RANS SST-1994m, Mach 3, alpha 40 degrees, Re=1e6.
- Mesh: medium 720 x 181, 130,320 points.
- Final loads: CL=0.923084 and CD=0.859027.
- Final residuals: rho=-3.428647, k=-4.038380, omega=+2.083470.
- Nonphysical points: zero in all reported continuation records.
- Restart: 130,321 CSV rows including the header; no NaN or Inf detected.
- SU2 convergence result: No; maximum iterations were reached before the
  density criterion of -10 and the omega residual remained unacceptable.
- Scientific use: initialize BDF1/BDF2 URANS only. Do not cite this as a
  converged steady, grid-independent, or qualified physical result.
