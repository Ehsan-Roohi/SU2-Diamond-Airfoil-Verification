# Current verified status

Last verified: 2026-08-13 05:31 CEST / 2026-08-12 23:31 EDT.

## Status label

CHECKPOINTED — medium-grid steady seed preparation completed naturally near
global iteration 20,000. Production URANS statistics have not started and no
result is qualified.

## Verified live state

- No solver process is active while the end-of-seed gate and BDF1 configuration
  are being audited.
- Case: Mach 3, alpha 40 degrees, Reynolds number 1e6, SST-1994m.
- Grid: medium, 720 x 181, 130,320 points.
- Latest complete restart: approximately global iteration 20,000,
  `runs/urans_alpha40/medium_dt/restart_seed_refined.csv`.
- Latest restart write time: 2026-08-13 05:30:37 CEST.
- Final continuation record: CL=0.923084, CD=0.859027, nonphysical points zero.
- Final residuals: rho=-3.428647, k=-4.038380, omega=+2.083470.
- SU2 reported `Converged = No`; this is a bounded initialization state, not a
  converged steady solution.

## Incident and recovery

- A PID-namespace mismatch briefly caused a second solver to be started on the
  same case. The newer duplicate was stopped immediately; the older solver was
  retained.
- The duplicate altered the live history path. The complete history through
  iteration 14,843 and the iteration-14,500 restart are preserved in
  `URANS_alpha40_seed_checkpoint_iter14500.zip` at the project root.
- The iteration-15,000 restart was subsequently written by the surviving
  solver and is the authoritative recovery state.
- Before any solver launch, use `runs/urans_alpha40/status_alpha40.sh`. A launch
  is forbidden unless it reports `solver_count=0`. More than one solver is a
  hard failure requiring manual selection of the duplicate to stop.

## Persistence status

- Scheduled hourly monitoring is active in this chat.
- Earlier control and seed-gate packages remain stored persistently.
- The iteration-15,000 recovery package is stored persistently as
  `URANS_alpha40_seed_checkpoint_iter15000.zip`.

## Required next actions

1. Store the final global-iteration-20,000 restart package persistently.
2. Bootstrap BDF1 using unique history/restart basenames and audit the inner
   convergence of both physical time steps.
3. Use the steady field only as an initial condition; do not call it
   a converged physical result when the separated flow remains intrinsically
   unsteady.
4. Qualify BDF2 inner convergence with unique history and
   restart basenames.
5. Run coarse_dt, medium_dt, fine_dt, and medium_halfdt.
6. Compute mean/RMS loads, grid and time-step sensitivity, y-plus, and native
   shock/separation topology before using the status QUALIFIED.
